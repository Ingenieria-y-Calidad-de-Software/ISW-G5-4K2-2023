import React from "react";

const Step5 = () => {
  return (
    <div>
      <h1>Paso 5</h1>
    </div>
  );
};

export default Step5;
